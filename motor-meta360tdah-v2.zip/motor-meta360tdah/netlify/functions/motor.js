// Netlify Serverless Function — META360TDAH Motor de Leitura
// Endpoint: POST /.netlify/functions/motor
// Body: payload Formspree em texto puro (exatamente como chega no e-mail)

const PILARES = {
  F_CASA:{nome:"Casa, Rotina e Comportamento Familiar",codigo:"C",cor:"#F26A35",
    campos:["cas_01","cas_02","cas_03","cas_04","cas_05"],
    itens:["C1","C2","C3","C4","C5"],
    descricoes:["Rotina depende de muita insistência dos adultos","Tarefas simples geram conflito","Pais precisam repetir comandos muitas vezes","Criança reage com oposição, irritação ou explosão","Casa só funciona se um adulto controla tudo"],
    blocos:{C1:"Rotina em 3 Passos",C2:"Tarefa sem Guerra",C3:"Comunicação que Funciona",C4:"Protocolo de Escalada",C5:"Escada de Autonomia Doméstica"},
    combinacoes:{
      "":{codigo:"PC00",leitura:"Não há ponto único de alta pressão. Se houver vários itens em 3, há pressão difusa.",acao:"Escolher o item de maior impacto para a família e intervir com rotina mínima por 14 a 30 dias."},
      "C1":{codigo:"PC01",leitura:"Rotina dependente de muita insistência. O adulto está usando energia verbal para sustentar o dia.",acao:"Criar rotina visual de 3 passos para um único momento crítico."},
      "C2":{codigo:"PC02",leitura:"Tarefas simples viraram gatilho de conflito. A entrada na tarefa está mal desenhada.",acao:"Reduzir a tarefa ao primeiro passo concreto e reforçar o início."},
      "C3":{codigo:"PC03",leitura:"A comunicação virou repetição. A criança responde tarde e o adulto se desgasta.",acao:"Usar comando curto, pausa de 5 segundos e pista visual."},
      "C4":{codigo:"PC04",leitura:"O eixo dominante é oposição, irritação ou explosão diante de limite.",acao:"Criar protocolo de escalada: falar menos, manter limite, retomar depois."},
      "C5":{codigo:"PC05",leitura:"A casa depende de controle adulto permanente. Há dependência executiva.",acao:"Escolher uma microresponsabilidade para transferência gradual."},
      "C1,C2":{codigo:"PC06",leitura:"Rotina instável e tarefas conflituosas. A criança entra na demanda sem previsibilidade suficiente.",acao:"Criar sequência fixa antes da tarefa crítica e avisar a transição."},
      "C1,C3":{codigo:"PC07",leitura:"Insistência adulta e repetição de comandos. O sistema depende de fala excessiva.",acao:"Externalizar a rotina em checklist visual e reduzir comandos verbais."},
      "C1,C4":{codigo:"PC08",leitura:"Rotina instável alimenta explosões. A falta de antecipação aumenta desregulação.",acao:"Usar antecipação e contagem regressiva antes das transições."},
      "C1,C5":{codigo:"PC09",leitura:"A rotina existe, mas está nas mãos do adulto.",acao:"Transformar rotina verbal em visual e transferir pequenas etapas."},
      "C2,C3":{codigo:"PC10",leitura:"Tarefas viram conflito e os comandos se repetem. Há fala demais antes da ação.",acao:"Falar menos, iniciar junto por 2 minutos e retirar ajuda gradualmente."},
      "C2,C4":{codigo:"PC11",leitura:"A tarefa é gatilho de explosão. A exigência inicial pode estar alta ou mal fracionada.",acao:"Pedir apenas o começo da tarefa e reforçar a tentativa."},
      "C2,C5":{codigo:"PC12",leitura:"Adultos assumem tarefas para evitar briga.",acao:"Adulto faz junto, não faz pela criança; definir tarefa que deixará de ser 100% adulta."},
      "C3,C4":{codigo:"PC13",leitura:"A repetição de comandos escala oposição.",acao:"Dar comando uma vez, oferecer escolha fechada e encerrar negociação."},
      "C3,C5":{codigo:"PC14",leitura:"A criança só age sob comando externo.",acao:"Trocar lembretes por checklist, alarme ou quadro visual."},
      "C4,C5":{codigo:"PC15",leitura:"A família controla tudo para evitar explosão.",acao:"Manter uma exigência mínima com limite calmo e ajustar depois da crise."},
      "C1,C2,C3":{codigo:"PC16",leitura:"Ciclo comando-resistência-repetição.",acao:"Implantar Rotina em 3 Passos por 14 dias."},
      "C1,C2,C4":{codigo:"PC17",leitura:"Demanda sem preparo vira crise.",acao:"Preparar ambiente, antecipar transição e reduzir exigência inicial."},
      "C1,C2,C5":{codigo:"PC18",leitura:"Adultos sustentam rotina e tarefas viram disputa quando há transferência.",acao:"Definir o que a criança faz sozinha, junto e o que o adulto confere."},
      "C1,C3,C4":{codigo:"PC19",leitura:"Comando verbal repetido é combustível da crise.",acao:"Reduzir fala, usar regra visual e pausa."},
      "C1,C3,C5":{codigo:"PC20",leitura:"Controle verbal adulto sustenta tudo.",acao:"Criar sistema externo que substitua pelo menos metade dos lembretes."},
      "C1,C4,C5":{codigo:"PC21",leitura:"Família organiza a casa para evitar crise, não para treinar habilidade.",acao:"Manter previsibilidade e reduzir um ponto de controle adulto por semana."},
      "C2,C3,C4":{codigo:"PC22",leitura:"Demandas viram negociação, repetição e explosão.",acao:"Selecionar uma regra inegociável da semana, com consequência previsível."},
      "C2,C3,C5":{codigo:"PC23",leitura:"Pedido, repetição, desgaste e adulto assume.",acao:"Usar ajuda mínima: adulto apoia o primeiro passo; criança executa o próximo."},
      "C2,C4,C5":{codigo:"PC24",leitura:"A escalada interrompe a demanda.",acao:"Permitir emoção, manter direção e retomar a tarefa após acalmar."},
      "C3,C4,C5":{codigo:"PC25",leitura:"A criança depende do adulto, mas reage ao controle adulto.",acao:"Diminuir comando direto; usar combinado visual e conferência posterior."},
      "C1,C2,C3,C4":{codigo:"PC26",leitura:"Alta pressão sem C5 dominante. Crise antes de autonomia.",acao:"Primeiro reduzir crise: rotina única, protocolo de escalada e comandos curtos por 7 dias."},
      "C1,C2,C3,C5":{codigo:"PC27",leitura:"A casa funciona às custas de sobrecarga parental.",acao:"Reduzir carga adulta e transferir uma microresponsabilidade."},
      "C1,C2,C4,C5":{codigo:"PC28",leitura:"Conflito, desorganização, explosão e dependência.",acao:"Intervir apenas no momento mais destrutivo do dia por 7 a 14 dias."},
      "C1,C3,C4,C5":{codigo:"PC29",leitura:"Adulto virou gerente, regulador e fiscal.",acao:"Trocar bronca por sinal combinado e quadro visual."},
      "C2,C3,C4,C5":{codigo:"PC30",leitura:"Demanda, repetição, explosão e adulto assume.",acao:"Tarefa em blocos de 5 minutos, reforçando início e retomada."},
      "C1,C2,C3,C4,C5":{codigo:"PC31",leitura:"Pilar Casa em suporte intensivo. A família está presa em sistema desgastado.",acao:"Rotina em 3 Passos + Protocolo de Escalada + redução de carga parental. Reavaliar em 7 dias."}
    },
    moduladores:{C1:"Adicionar previsibilidade: rotina visual ou antecipação.",C2:"Reduzir entrada em demanda: primeiro passo concreto ou tarefa de 2 minutos.",C3:"Economizar linguagem adulta: comando curto, esperar e evitar repetição.",C4:"Prevenir escalada: protocolo de pausa leve.",C5:"Iniciar microautonomia: uma tarefa para a criança participar mais."},
    estrategias:{C1:["Rotina em 3 Passos","Checklist visual","Antecipação","Contagem regressiva","Externalização da informação","Tempo externo"],C2:["Tarefa de 2 minutos","Primeiro passo concreto","Scaffolding / andaime","Ajuda mínima necessária","Reforço por início"],C3:["Comando curto","Regra dos 5 segundos","Economia de comandos","Recrutamento de atenção","Redução de linguagem"],C4:["Protocolo de pausa","Limite calmo","Retomada pós-crise","Tolerância à frustração","Consequência imediata","Consequência previsível"],C5:["Escada de autonomia","Transferência gradual","Conferência posterior","Microhabilidade","Reforço antes de punição"]}
  },
  F_MEDICACAO:{nome:"Clínico-Medicamentoso",codigo:"M",cor:"#5B8AF5",
    campos:["med_01","med_02","med_03","med_04","med_05"],
    itens:["M1","M2","M3","M4","M5"],
    descricoes:["Dúvida se o tratamento atual funciona de forma suficiente","Efeito oscila entre manhã, escola, tarde e noite","Sinais como irritabilidade, sonolência, apetite reduzido, insônia ou piora no fim do dia","Prejuízo importante persiste em casa, escola ou tarefas","Insegurança sobre horário, duração, adesão ou necessidade de ajuste"],
    blocos:{M1:"Monitoramento Clínico de 7 dias",M2:"Mapa de Efeito Diário",M3:"Diário de Efeitos Adversos",M4:"Comparativo Casa-Escola",M5:"Revisão de Adesão e Horários"},
    combinacoes:{
      "":{codigo:"PM00",leitura:"Sem pressão alta isolada. Manutenção ativa com vigilância estruturada.",acao:"Manter vigilância estruturada e focar o item de maior pontuação relativa."},
      "M1":{codigo:"PM01",leitura:"Dúvida de eficácia percebida.",acao:"Aplicar Monitoramento Clínico de 7 dias para separar expectativa, efeito real e prejuízo funcional."},
      "M2":{codigo:"PM02",leitura:"Oscilação do efeito ao longo do dia.",acao:"Usar Mapa de Efeito Diário por horários: antes da escola, escola, almoço, tarde e noite."},
      "M3":{codigo:"PM03",leitura:"Possível efeito adverso ou rebote.",acao:"Acionar Diário de Efeitos Adversos e avaliar necessidade de contato clínico."},
      "M4":{codigo:"PM04",leitura:"Tratamento existe, mas funcionamento ainda está prejudicado.",acao:"Fazer Comparativo Casa-Escola para definir se é medicação, ambiente, rotina, escola ou comorbidade."},
      "M5":{codigo:"PM05",leitura:"Insegurança operacional da família.",acao:"Revisar adesão, horário, duração, faltas, pausas e entendimento do plano."},
      "M1,M2":{codigo:"PM06",leitura:"Dúvida de efeito associada à oscilação.",acao:"Monitorar por faixa horária e cruzar com relato escolar."},
      "M1,M3":{codigo:"PM07",leitura:"Dúvida de eficácia misturada a possíveis efeitos adversos.",acao:"Separar benefício e custo: registrar melhora, efeitos indesejados e horários."},
      "M1,M4":{codigo:"PM08",leitura:"Família duvida do tratamento porque prejuízo persiste.",acao:"Checar se prejuízo é sintoma residual, demanda ambiental ou alvo não medicamentoso."},
      "M1,M5":{codigo:"PM09",leitura:"Dúvida de efeito com insegurança de uso.",acao:"Antes de discutir troca, conferir adesão, horário, regularidade e expectativas."},
      "M2,M3":{codigo:"PM10",leitura:"Oscilação com possível rebote ou colateral.",acao:"Mapear horário de início, pico, queda e comportamento no fim do efeito."},
      "M2,M4":{codigo:"PM11",leitura:"Efeito pode não cobrir períodos críticos.",acao:"Cruzar horários de prejuízo com rotina escolar e familiar."},
      "M2,M5":{codigo:"PM12",leitura:"Oscilação aumenta insegurança dos pais.",acao:"Criar mapa simples: horário de uso, efeito percebido, queda e prejuízo."},
      "M3,M4":{codigo:"PM13",leitura:"Prejuízo e possível efeito adverso simultâneo.",acao:"Diferenciar piora por colateral de prejuízo basal persistente."},
      "M3,M5":{codigo:"PM14",leitura:"Efeitos percebidos aumentam insegurança familiar.",acao:"Fazer diário de sintomas físicos e emocionais antes de nova decisão."},
      "M4,M5":{codigo:"PM15",leitura:"Prejuízo persistente e família insegura.",acao:"Reorganizar plano de acompanhamento e definir necessidade de revisão clínica."},
      "M1,M2,M3":{codigo:"PM16",leitura:"Dúvida, oscilação e possível colateral.",acao:"Monitoramento Clínico de 7 dias obrigatório antes de interpretação definitiva."},
      "M1,M2,M4":{codigo:"PM17",leitura:"Efeito incerto, oscilante e prejuízo persistente.",acao:"Fazer leitura funcional por ambiente e horário."},
      "M1,M2,M5":{codigo:"PM18",leitura:"Família percebe efeito instável e não sabe conduzir.",acao:"Revisar uso, horários, expectativa de duração e critério de resposta."},
      "M1,M3,M4":{codigo:"PM19",leitura:"Benefício duvidoso com possível custo funcional.",acao:"Considerar avaliação clínica mais próxima se houver piora recente."},
      "M1,M3,M5":{codigo:"PM20",leitura:"Insegurança alta por possível efeito adverso.",acao:"Orientar registro objetivo; evitar decisões baseadas só em impressão do dia."},
      "M1,M4,M5":{codigo:"PM21",leitura:"Tratamento não convence e prejuízo continua.",acao:"Reavaliar metas: o que se espera da medicação e o que exige intervenção não medicamentosa."},
      "M2,M3,M4":{codigo:"PM22",leitura:"Oscilação, colateral e prejuízo coexistem.",acao:"Alta prioridade: mapear cronologia e discutir revisão clínica."},
      "M2,M3,M5":{codigo:"PM23",leitura:"Família insegura por oscilação e sintomas associados.",acao:"Diário por horário + checagem de adesão + orientação de acionamento médico."},
      "M2,M4,M5":{codigo:"PM24",leitura:"Efeito irregular com prejuízo e insegurança.",acao:"Comparativo casa-escola e revisão do plano de uso."},
      "M3,M4,M5":{codigo:"PM25",leitura:"Possível efeito adverso com prejuízo e insegurança.",acao:"Tratar como suporte prioritário; avaliar contato clínico em curto prazo."},
      "M1,M2,M3,M4":{codigo:"PM26",leitura:"Quatro áreas clínicas pressionadas.",acao:"Suporte intensivo: monitoramento objetivo e possível revisão clínica."},
      "M1,M2,M3,M5":{codigo:"PM27",leitura:"Família insegura diante de oscilação e possíveis colaterais.",acao:"Organizar dados antes da consulta: efeito, queda, sono, apetite, humor e escola."},
      "M1,M2,M4,M5":{codigo:"PM28",leitura:"Efeito incerto, instável, prejuízo persistente e insegurança.",acao:"Reavaliar plano global: resposta medicamentosa versus ambiente desorganizado."},
      "M1,M3,M4,M5":{codigo:"PM29",leitura:"Dúvida de efeito, colateral, prejuízo e insegurança.",acao:"Alta prioridade: contato clínico ou revisão programada em curto prazo."},
      "M2,M3,M4,M5":{codigo:"PM30",leitura:"Oscilação, colateral, prejuízo e insegurança.",acao:"Provável instabilidade do plano medicamentoso; organizar monitoramento."},
      "M1,M2,M3,M4,M5":{codigo:"PM31",leitura:"Todos os itens altos. Pilar Clínico-Medicamentoso em suporte intensivo.",acao:"Não resolver por mensagem solta; precisa de leitura clínica estruturada."}
    },
    moduladores:{M1:"Perguntar qual melhora a família esperava e qual melhora observou.",M2:"Adicionar registro por horário.",M3:"Rastrear sono, apetite, irritabilidade, dor de cabeça e dor abdominal.",M4:"Cruzar funcionamento em casa e escola.",M5:"Revisar adesão, horários e entendimento do plano."},
    estrategias:{M1:["Monitoramento Clínico de 7 dias","Comparativo Casa-Escola"],M2:["Mapa de Efeito Diário"],M3:["Diário de Efeitos Adversos"],M4:["Comparativo Casa-Escola","Escola360"],M5:["Revisão de Adesão e Horários"]}
  },
  F_ESCOLA:{nome:"Escola e Aprendizagem",codigo:"E",cor:"#34D399",
    campos:["esc_01","esc_02","esc_03","esc_04","esc_05"],
    itens:["E1","E2","E3","E4","E5"],
    descricoes:["Escola relata prejuízo de atenção, comportamento ou rendimento","Provas, lições, cópias ou tarefas são fonte de dificuldade importante","Dificuldade de organização com material, agenda, prazos ou instruções","Escola aponta problemas sem clareza sobre adaptação prática","Comunicação família-escola-tratamento insuficiente ou desalinhada"],
    blocos:{E1:"Escola360",E2:"Plano de Tarefa e Prova",E3:"Organização Escolar Guiada",E4:"Adaptação Prioritária",E5:"Ponte Família-Escola"},
    combinacoes:{
      "":{codigo:"PE00",leitura:"Sem pressão alta isolada, mas há possível necessidade preventiva.",acao:"Escolher o item escolar mais pontuado e manter acompanhamento proporcional."},
      "E1":{codigo:"PE01",leitura:"A escola percebe prejuízo, mas o mecanismo ainda não está claro.",acao:"Solicitar descrição objetiva: quando, onde, frequência e impacto."},
      "E2":{codigo:"PE02",leitura:"Gargalo em prova, lição, cópia ou tarefa.",acao:"Acionar Plano de Tarefa e Prova."},
      "E3":{codigo:"PE03",leitura:"Eixo central é organização escolar.",acao:"Acionar Organização Escolar Guiada."},
      "E4":{codigo:"PE04",leitura:"A escola reclama, mas não traduz em adaptação.",acao:"Uma queixa, uma estratégia, um prazo."},
      "E5":{codigo:"PE05",leitura:"Desalinhamento de comunicação.",acao:"Acionar Ponte Família-Escola."},
      "E1,E2":{codigo:"PE06",leitura:"Queixa escolar aparece principalmente em desempenho/tarefas.",acao:"Separar atenção, dificuldade acadêmica e demanda executiva."},
      "E1,E3":{codigo:"PE07",leitura:"Prejuízo percebido com desorganização evidente.",acao:"Criar plano de material, agenda e instruções."},
      "E1,E4":{codigo:"PE08",leitura:"Escola identifica problema, mas não sabe adaptar.",acao:"Traduzir queixa em adaptação testável por 14 dias."},
      "E1,E5":{codigo:"PE09",leitura:"Escola reclama e comunicação está desalinhada.",acao:"Fazer contato estruturado com escola antes de orientar família isoladamente."},
      "E2,E3":{codigo:"PE10",leitura:"Dificuldade acadêmica associada à organização.",acao:"Plano de prova/tarefa + checklist de material e prazos."},
      "E2,E4":{codigo:"PE11",leitura:"Dificuldade em tarefas/provas sem adaptação definida.",acao:"Definir uma adaptação: tempo, instrução curta, divisão de tarefa ou redução de cópia."},
      "E2,E5":{codigo:"PE12",leitura:"Dificuldade acadêmica com comunicação falha.",acao:"Solicitar exemplos concretos de prova, tarefa e lição."},
      "E3,E4":{codigo:"PE13",leitura:"Desorganização reconhecida sem plano prático.",acao:"Criar rotina escolar mínima: agenda, material, conferência."},
      "E3,E5":{codigo:"PE14",leitura:"Desorganização piora por baixa coordenação família-escola.",acao:"Criar canal simples de comunicação e checklist comum."},
      "E4,E5":{codigo:"PE15",leitura:"Queixa vaga e comunicação ruim.",acao:"Organizar a conversa antes de produzir relatório longo."},
      "E1,E2,E3":{codigo:"PE16",leitura:"Prejuízo escolar amplo: atenção, tarefa e organização.",acao:"Acionar Escola360 com três alvos, iniciando por apenas um."},
      "E1,E2,E4":{codigo:"PE17",leitura:"Queixa e prejuízo existem, mas falta adaptação.",acao:"Escolher adaptação prioritária para tarefa/prova."},
      "E1,E2,E5":{codigo:"PE18",leitura:"Prejuízo escolar com comunicação insuficiente.",acao:"Reunir dados de professor e família antes de definir conduta."},
      "E1,E3,E4":{codigo:"PE19",leitura:"Queixa escolar com desorganização e ausência de adaptação.",acao:"Plano de organização escolar + adaptação simples em sala."},
      "E1,E3,E5":{codigo:"PE20",leitura:"Prejuízo e desorganização com desalinhamento.",acao:"Ponte Família-Escola + checklist semanal."},
      "E1,E4,E5":{codigo:"PE21",leitura:"Escola reclama, não adapta e comunicação falha.",acao:"Alinhar expectativas e solicitar uma queixa operacional."},
      "E2,E3,E4":{codigo:"PE22",leitura:"Tarefa/prova e organização sem adaptação definida.",acao:"Plano de tarefa/prova + organização guiada + uma adaptação."},
      "E2,E3,E5":{codigo:"PE23",leitura:"Dificuldade acadêmica e organização com comunicação frágil.",acao:"Enviar roteiro de observação para professor."},
      "E2,E4,E5":{codigo:"PE24",leitura:"Provas/tarefas prejudicadas e escola desalinhada.",acao:"Definir ajuste acadêmico e canal de retorno em 14 a 30 dias."},
      "E3,E4,E5":{codigo:"PE25",leitura:"Desorganização sem plano e sem comunicação eficaz.",acao:"Escola360 focado em organização, checklist e responsável definido."},
      "E1,E2,E3,E4":{codigo:"PE26",leitura:"Prejuízo amplo sem adaptação clara.",acao:"Escolher uma adaptação e um indicador de melhora."},
      "E1,E2,E3,E5":{codigo:"PE27",leitura:"Prejuízo amplo com comunicação desalinhada.",acao:"Fazer ponte escola-família antes de escalar intervenções."},
      "E1,E2,E4,E5":{codigo:"PE28",leitura:"Queixa, tarefa/prova, falta de adaptação e comunicação frágil.",acao:"Contato estruturado com escola; evitar orientação só para os pais."},
      "E1,E3,E4,E5":{codigo:"PE29",leitura:"Queixa, desorganização, falta de plano e desalinhamento.",acao:"Plano escolar mínimo com rotina de conferência."},
      "E2,E3,E4,E5":{codigo:"PE30",leitura:"Dificuldade acadêmica e executiva com escola sem plano.",acao:"Escola360 com foco em tarefa, prova e organização."},
      "E1,E2,E3,E4,E5":{codigo:"PE31",leitura:"Pilar Escola em suporte intensivo. Exige ação coordenada com escola.",acao:"Não apenas orientação familiar — coordenação escola-família obrigatória."}
    },
    moduladores:{E1:"Solicitar relato objetivo do professor.",E2:"Incluir estratégia de prova/tarefa antes de crise acadêmica.",E3:"Introduzir checklist escolar leve.",E4:"Definir uma adaptação prioritária.",E5:"Organizar canal de comunicação com escola."},
    estrategias:{E1:["Escola360","Comparativo Casa-Escola","Indicador escolar de melhora"],E2:["Plano de Tarefa e Prova","Adaptação prioritária","Tarefa de 5 minutos","Scaffolding / andaime"],E3:["Organização Escolar Guiada","Checklist visual","Central Executiva","Externalização da informação"],E4:["Adaptação prioritária","Escola360","Indicador escolar de melhora"],E5:["Ponte Família-Escola","Escola360"]}
  },
  F_SOCIAL:{nome:"Regulação Emocional e Comportamento Social",codigo:"S",cor:"#A78BFA",
    campos:["soc_01","soc_02","soc_03","soc_04","soc_05"],
    itens:["S1","S2","S3","S4","S5"],
    descricoes:["Conflitos frequentes com colegas, irmãos ou adultos","Pequenas frustrações geram reações emocionais intensas","Impulsividade verbal ou física prejudica relações","Dificuldade de reparar, pedir desculpas ou reconhecer impacto","Rejeição, isolamento, exclusão ou desgaste social relevante"],
    blocos:{S1:"Mapa de Gatilhos Sociais",S2:"Pausa Social Combinada",S3:"Pausa Social Combinada",S4:"Treino de Reparação",S5:"Plano de Pertencimento"},
    combinacoes:{
      "":{codigo:"PS00",leitura:"Sem pressão alta isolada, mas pode haver risco social preventivo.",acao:"Monitorar item mais pontuado e orientar manutenção ativa."},
      "S1":{codigo:"PS01",leitura:"Frequência de conflito é o ponto principal.",acao:"Mapear onde, com quem e em que momento ocorre."},
      "S2":{codigo:"PS02",leitura:"Baixa tolerância à frustração.",acao:"Trabalhar Pausa Social Combinada e linguagem de frustração."},
      "S3":{codigo:"PS03",leitura:"Impulsividade está ferindo relações.",acao:"Criar estratégia de interrupção antes do ato ou fala impulsiva."},
      "S4":{codigo:"PS04",leitura:"Dificuldade está na reparação pós-episódio.",acao:"Treino de reparação: reconhecer, reparar e retomar."},
      "S5":{codigo:"PS05",leitura:"Dano principal é pertencimento social.",acao:"Plano de Pertencimento e avaliação de sofrimento."},
      "S1,S2":{codigo:"PS06",leitura:"Conflitos nascem de frustrações mal toleradas.",acao:"Mapear gatilho e treinar pausa antes da reação."},
      "S1,S3":{codigo:"PS07",leitura:"Conflito frequente com impulsividade verbal/física.",acao:"Intervenção antes do conflito: sinais, pausa, supervisão."},
      "S1,S4":{codigo:"PS08",leitura:"A criança conflita e não repara.",acao:"Treino de reparação obrigatório após episódio."},
      "S1,S5":{codigo:"PS09",leitura:"Conflito já produz exclusão ou desgaste.",acao:"Plano de redução de conflito + pertencimento social."},
      "S2,S3":{codigo:"PS10",leitura:"Frustração vira impulsividade.",acao:"Pausa combinada e regra de segurança: sentir pode, agredir não."},
      "S2,S4":{codigo:"PS11",leitura:"Criança explode e depois não consegue reparar.",acao:"Separar momento de crise do momento de reparação."},
      "S2,S5":{codigo:"PS12",leitura:"Baixa tolerância à frustração afeta pertencimento.",acao:"Treinar frustração em situações pequenas e previsíveis."},
      "S3,S4":{codigo:"PS13",leitura:"Impulsividade causa dano e reparação falha.",acao:"Criar roteiro de reparação simples e repetível."},
      "S3,S5":{codigo:"PS14",leitura:"Impulsividade leva à rejeição.",acao:"Reduzir episódios de alto impacto e orientar ambiente."},
      "S4,S5":{codigo:"PS15",leitura:"Falta de reparação mantém rejeição ou afastamento.",acao:"Reparação assistida e reconstrução de vínculo."},
      "S1,S2,S3":{codigo:"PS16",leitura:"Conflito, frustração e impulsividade formam ciclo rápido.",acao:"Plano de Regulação e Reparação com foco em prevenção."},
      "S1,S2,S4":{codigo:"PS17",leitura:"Conflito por frustração sem reparação suficiente.",acao:"Pausa + retomada pós-crise + reparação."},
      "S1,S2,S5":{codigo:"PS18",leitura:"Conflitos por frustração prejudicam pertencimento.",acao:"Reduzir exposição a gatilhos sem treino e criar contexto de sucesso social."},
      "S1,S3,S4":{codigo:"PS19",leitura:"Conflito impulsivo com falha de reparação.",acao:"Interromper padrão antes, durante e depois do episódio."},
      "S1,S3,S5":{codigo:"PS20",leitura:"Conflito impulsivo gerando rejeição.",acao:"Plano de segurança social e alinhamento com escola/família."},
      "S1,S4,S5":{codigo:"PS21",leitura:"Conflitos sem reparação sustentam exclusão.",acao:"Reparação guiada + reconstrução gradual de confiança."},
      "S2,S3,S4":{codigo:"PS22",leitura:"Frustração, impulsividade e reparação ruim.",acao:"Treinar frase de pausa e roteiro pós-episódio."},
      "S2,S3,S5":{codigo:"PS23",leitura:"Frustração impulsiva já impacta pertencimento.",acao:"Plano de pertencimento com ambientes estruturados."},
      "S2,S4,S5":{codigo:"PS24",leitura:"Explosão emocional sem reparação gera afastamento.",acao:"Trabalhar reparação depois de acalmar; não exigir insight no pico."},
      "S3,S4,S5":{codigo:"PS25",leitura:"Impulsividade e ausência de reparação geram rejeição.",acao:"Redução de dano social + treino de reparação + supervisão."},
      "S1,S2,S3,S4":{codigo:"PS26",leitura:"Ciclo completo de conflito sem pertencimento como queixa central.",acao:"Suporte prioritário: prevenir escalada e reparar depois."},
      "S1,S2,S3,S5":{codigo:"PS27",leitura:"Conflito impulsivo com prejuízo social relevante.",acao:"Suporte intensivo se houver agressão ou exclusão."},
      "S1,S2,S4,S5":{codigo:"PS28",leitura:"Conflito emocional sem reparação e com exclusão.",acao:"Plano de Regulação e Reparação + Pertencimento."},
      "S1,S3,S4,S5":{codigo:"PS29",leitura:"Conflito impulsivo, sem reparação, com dano social.",acao:"Alta prioridade: reduzir dano, alinhar adultos e escola."},
      "S2,S3,S4,S5":{codigo:"PS30",leitura:"Frustração/impulsividade sem reparação e com isolamento.",acao:"Plano intensivo de regulação e pertencimento."},
      "S1,S2,S3,S4,S5":{codigo:"PS31",leitura:"Pilar Social em suporte intensivo. Exige plano de segurança, regulação e reparação.",acao:"Plano de segurança, regulação e reparação obrigatórios."}
    },
    moduladores:{S1:"Mapear frequência e contexto dos conflitos.",S2:"Incluir treino de tolerância à frustração.",S3:"Incluir estratégia de pausa antes da resposta impulsiva.",S4:"Incluir reparação simples pós-episódio.",S5:"Monitorar pertencimento e sinais de isolamento."},
    estrategias:{S1:["Mapa de Gatilhos Sociais","Regra da casa","Consequência previsível"],S2:["Pausa Social Combinada","Tolerância à frustração","Protocolo de pausa","Limite calmo"],S3:["Pausa Social Combinada","Regra de segurança social","Redução de linguagem","Protocolo de pausa"],S4:["Treino de Reparação","Reparação assistida","Retomada pós-crise"],S5:["Plano de Pertencimento","Redução de dano social","Reparação assistida"]}
  },
  F_AUTONOMIA:{nome:"Autonomia, Funções Executivas e Desenvolvimento",codigo:"A",cor:"#FBBF24",
    campos:["aut_01","aut_02","aut_03","aut_04","aut_05"],
    itens:["A1","A2","A3","A4","A5"],
    descricoes:["Criança depende de adulto para iniciar tarefas simples","Pais organizam mochila, agenda, materiais ou tarefas com muita frequência","Criança esquece combinados, perde prazos ou não sustenta responsabilidades","Dificuldade com planejamento, tempo, sequência de passos ou conclusão","Pais receiam estar fazendo pela criança o que ela precisa aprender com apoio"],
    blocos:{A1:"Início Assistido",A2:"Organização de Materiais",A3:"Sistema de Memória Externa",A4:"Sequência e Tempo",A5:"Escada de Autonomia"},
    combinacoes:{
      "":{codigo:"PA00",leitura:"Sem pressão alta isolada. Manutenção ativa de autonomia.",acao:"Escolher uma microhabilidade e manter treino preventivo."},
      "A1":{codigo:"PA01",leitura:"A principal barreira é iniciar.",acao:"Usar Início Assistido e primeiro passo concreto."},
      "A2":{codigo:"PA02",leitura:"Adultos sustentam organização material.",acao:"Criar Organização de Materiais com checklist."},
      "A3":{codigo:"PA03",leitura:"Memória operacional e responsabilidade estão frágeis.",acao:"Usar Sistema de Memória Externa."},
      "A4":{codigo:"PA04",leitura:"Planejamento, tempo e sequência são o eixo.",acao:"Usar Sequência e Tempo com passos visuais."},
      "A5":{codigo:"PA05",leitura:"Pais percebem dependência executiva.",acao:"Acionar Escada de Autonomia e reduzir ajuda gradualmente."},
      "A1,A2":{codigo:"PA06",leitura:"Criança não inicia e adultos organizam por ela.",acao:"Início assistido + checklist de material."},
      "A1,A3":{codigo:"PA07",leitura:"Falha em iniciar e lembrar combinados.",acao:"Primeiro passo concreto + memória externa."},
      "A1,A4":{codigo:"PA08",leitura:"Início prejudicado por dificuldade de planejar sequência.",acao:"Dividir tarefa em etapas e começar junto."},
      "A1,A5":{codigo:"PA09",leitura:"Pais iniciam pela criança para evitar travamento.",acao:"Adulto inicia junto, mas não substitui execução."},
      "A2,A3":{codigo:"PA10",leitura:"Organização e memória dependem dos pais.",acao:"Checklist diário e conferência posterior."},
      "A2,A4":{codigo:"PA11",leitura:"Material e sequência estão desorganizados.",acao:"Criar rotina de organização em passos fixos."},
      "A2,A5":{codigo:"PA12",leitura:"Pais estão organizando demais.",acao:"Transferir uma etapa de organização para a criança."},
      "A3,A4":{codigo:"PA13",leitura:"Esquecimento associado a falha de planejamento.",acao:"Sistema externo de prazos + sequência visual."},
      "A3,A5":{codigo:"PA14",leitura:"Pais compensam esquecimentos cronicamente.",acao:"Reduzir lembrete verbal e usar memória externa."},
      "A4,A5":{codigo:"PA15",leitura:"Pais assumem porque planejamento da criança falha.",acao:"Escada de autonomia focada em sequência de passos."},
      "A1,A2,A3":{codigo:"PA16",leitura:"Início, organização e memória dependem do adulto.",acao:"Uma rotina executiva por vez."},
      "A1,A2,A4":{codigo:"PA17",leitura:"Início, material e sequência frágeis.",acao:"Preparar ambiente + checklist + início assistido."},
      "A1,A2,A5":{codigo:"PA18",leitura:"Adultos organizam e iniciam pela criança.",acao:"Definir o que o adulto deixará de fazer nesta semana."},
      "A1,A3,A4":{codigo:"PA19",leitura:"A criança trava por falha executiva ampla.",acao:"Tarefa curta com suporte visual e temporizador."},
      "A1,A3,A5":{codigo:"PA20",leitura:"Pais compensam início e memória.",acao:"Transferir lembrete para sistema externo, não para bronca."},
      "A1,A4,A5":{codigo:"PA21",leitura:"Pais substituem porque iniciar e sequenciar é difícil.",acao:"Adulto faz junto apenas o primeiro passo e retira ajuda."},
      "A2,A3,A4":{codigo:"PA22",leitura:"Organização, memória e planejamento pressionados.",acao:"Criar central executiva: agenda, checklist e conferência."},
      "A2,A3,A5":{codigo:"PA23",leitura:"Pais viraram sistema de organização e memória.",acao:"Redução de ajuda adulta com checklist compartilhado."},
      "A2,A4,A5":{codigo:"PA24",leitura:"Pais organizam porque a sequência falha.",acao:"Ensinar sequência de organização em 3 passos."},
      "A3,A4,A5":{codigo:"PA25",leitura:"Pais compensam memória e planejamento.",acao:"Sistema de memória externa + escada de autonomia."},
      "A1,A2,A3,A4":{codigo:"PA26",leitura:"Funções executivas operacionais pressionadas.",acao:"Mostrar à família que há dependência funcional mesmo que não perceba."},
      "A1,A2,A3,A5":{codigo:"PA27",leitura:"Pais percebem dependência em início, organização e memória.",acao:"Transferir uma microhabilidade por ciclo."},
      "A1,A2,A4,A5":{codigo:"PA28",leitura:"Pais substituem início, material e planejamento.",acao:"Escada de autonomia com início assistido e checklist."},
      "A1,A3,A4,A5":{codigo:"PA29",leitura:"Dependência ampla em iniciar, lembrar e planejar.",acao:"Não cobrar autonomia total; treinar sequência mínima."},
      "A2,A3,A4,A5":{codigo:"PA30",leitura:"Pais sustentam organização, memória e planejamento.",acao:"Reduzir carga parental com sistema externo e conferência posterior."},
      "A1,A2,A3,A4,A5":{codigo:"PA31",leitura:"Pilar Autonomia em suporte intensivo.",acao:"Parar de substituir e começar a treinar em microetapas."}
    },
    moduladores:{A1:"Incluir primeiro passo concreto.",A2:"Introduzir checklist de materiais.",A3:"Usar memória externa para combinados e prazos.",A4:"Dividir tarefas em sequência curta.",A5:"Discutir redução gradual de ajuda adulta."},
    estrategias:{A1:["Início Assistido","Primeiro passo concreto","Scaffolding / andaime","Tarefa de 2 minutos"],A2:["Organização de Materiais","Checklist visual","Central Executiva","Conferência posterior"],A3:["Sistema de Memória Externa","Externalização da informação","Central Executiva","Checklist visual"],A4:["Sequência e Tempo","Tempo externo","Tarefa de 5 minutos","Preparação ambiental"],A5:["Escada de autonomia","Transferência gradual","Microhabilidade","Ajuda mínima necessária","Conferência posterior"]}
  }
};

const NIVEL_LABEL=["","Nível 1 — Manutenção ativa","Nível 2 — Suporte preventivo-focal","Nível 3 — Suporte prioritário","Nível 4 — Suporte intensivo"];

// Linhas que o Formspree injeta e não são campos reais
const LINHAS_LIXO = /^(_status|pessoafabio@|May\s+\d|[A-Z][a-z]+\s+\d{1,2},\s+\d{4})/i;
// Chaves que não são dados de formulário
const CHAVES_IGNORAR = /^(pessoafabio|_status|resultado_)/;

function parsePayload(txt) {
  const obj = {};
  const lines = txt.split("\n").map(l => l.trim()).filter(Boolean);
  let key = null;
  for (const line of lines) {
    // Ignora linhas de lixo antes de processá-las como valor
    if (LINHAS_LIXO.test(line) && !line.startsWith("* ")) { key = null; continue; }
    if (line.startsWith("* ")) {
      key = line.slice(2).trim();
      if (CHAVES_IGNORAR.test(key)) { key = null; continue; }
      obj[key] = "";
    } else if (key) {
      // Concatena mas ignora tokens de lixo inline (ex: "Sim _status")
      const clean = line.replace(/\s*_status\s*/gi,"").trim();
      if (clean) obj[key] = (obj[key] ? obj[key] + " " : "") + clean;
    }
  }
  // Normalizar hífens → underscore
  const norm = {};
  for (const [k,v] of Object.entries(obj)) norm[k.replace(/-/g,"_")] = v.trim();
  // Detectar formulário pelo subject se id_formulario ausente
  if (!norm.id_formulario && norm._subject) {
    const s = norm._subject;
    if (/casa|rotina/i.test(s))       norm.id_formulario = "F_CASA";
    else if (/medica/i.test(s))       norm.id_formulario = "F_MEDICACAO";
    else if (/escola|aprendiz/i.test(s)) norm.id_formulario = "F_ESCOLA";
    else if (/social|emocional/i.test(s)) norm.id_formulario = "F_SOCIAL";
    else if (/autonomia|execut/i.test(s)) norm.id_formulario = "F_AUTONOMIA";
  }
  return norm;
}

function processar(payload) {
  const id = payload.id_formulario;
  const pilar = PILARES[id];
  if (!pilar) return null;
  const pontuacoes = pilar.campos.map((c,i) => ({
    item: pilar.itens[i], desc: pilar.descricoes[i], nota: parseInt(payload[c])||0
  }));
  const soma = pontuacoes.reduce((a,b)=>a+b.nota,0);
  const nivel = soma<=9?1:soma<=14?2:soma<=19?3:4;
  const altos = pontuacoes.filter(p=>p.nota>=4).map(p=>p.item).sort();
  const moderados = pontuacoes.filter(p=>p.nota===3).map(p=>p.item);
  const alertasRaw = payload.alertas_resumo||"";
  const alertas = (alertasRaw && alertasRaw!=="Nenhum alerta selecionado") ? [alertasRaw] : [];
  const chave = altos.join(",");
  const combinacao = pilar.combinacoes[chave]||pilar.combinacoes[""];
  const blocos = [...new Set(altos.map(i=>pilar.blocos[i]).filter(Boolean))];
  if(!blocos.length && moderados.length) blocos.push(pilar.blocos[moderados[0]]);
  const estSet = new Set();
  altos.forEach(i=>(pilar.estrategias[i]||[]).forEach(e=>estSet.add(e)));
  if(!estSet.size) moderados.forEach(i=>(pilar.estrategias[i]||[]).forEach(e=>estSet.add(e)));
  const modsAtivos = moderados.map(i=>pilar.moduladores[i]).filter(Boolean);
  const prazo = nivel===4?"7 dias":nivel===3?"14 dias":nivel===2?"14 a 30 dias":"30 dias";
  const escalonamentoClinico = id==="F_MEDICACAO"&&(nivel>=3||alertas.length>0);
  return {
    pilar,id,nivel,soma,altos,moderados,alertas,combinacao,blocos,
    estrategias:[...estSet],modsAtivos,prazo,escalonamentoClinico,
    nomeCrianca:payload.nome_crianca||"—",
    responsavel:payload.responsavel||"—",
    idade:payload.idade||"—",
    periodo:payload.periodo_observado||"—",
    usaMedicacao:payload.usa_medicacao||"—",
    mudancaRecente:payload.mudanca_recente||"—",
    pontuacoes
  };
}

function gerarDevolutiva(r) {
  const esc = r.escalonamentoClinico?`🔴 ESCALONAMENTO CLÍNICO OBRIGATÓRIO\nNão enviar sem revisão do Dr. Fabio Pessoa.\n\n`:"";
  const alertStr = r.alertas.length?`⚠ ALERTA ATIVO: ${r.alertas.join("; ")}\n\n`:"";
  const mods = r.modsAtivos.length?`\nMODULADORES ATIVOS\n${r.modsAtivos.map(m=>`• ${m}`).join("\n")}`:"";
  const ests = r.estrategias.length?`\n\nESTRATÉGIAS DO GLOSSÁRIO\n${r.estrategias.map(e=>`• ${e}`).join("\n")}`:"";
  return `RASCUNHO DE DEVOLUTIVA — META360TDAH
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Criança : ${r.nomeCrianca} (${r.idade})
Responsável : ${r.responsavel}
Pilar : ${r.pilar.nome}
Período : ${r.periodo}
Gerado em : ${new Date().toLocaleDateString("pt-BR")}

${alertStr}${esc}RESULTADO
Pontuação  : ${r.soma}/25
Nível      : ${NIVEL_LABEL[r.nivel]}
Padrão     : ${r.combinacao.codigo}
Itens altos: ${r.altos.join(", ")||"nenhum"}
Moderados  : ${r.moderados.join(", ")||"nenhum"}
Alertas    : ${r.alertas.join("; ")||"nenhum"}

LEITURA INTERNA
${r.combinacao.leitura}

PRIMEIRO MOVIMENTO
→ ${r.combinacao.acao}

BLOCOS DE CUIDADO
${r.blocos.join(" · ")||"Manutenção ativa"}${mods}${ests}

PRAZO DE REAVALIAÇÃO: ${r.prazo}
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
[Equipe: personalizar com contexto antes de enviar]`;
}

exports.handler = async function(event) {
  // CORS headers para permitir chamadas do Make
  const headers = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Access-Control-Allow-Methods': 'POST, OPTIONS',
    'Content-Type': 'application/json'
  };

  // Preflight OPTIONS
  if (event.httpMethod === 'OPTIONS') {
    return { statusCode: 200, headers, body: '' };
  }

  if (event.httpMethod !== 'POST') {
    return { statusCode: 405, headers, body: JSON.stringify({ erro: 'Método não permitido. Use POST.' }) };
  }

  try {
    const body = event.body || '';

    // Aceita tanto texto puro (payload Formspree) quanto JSON
    let payload;
    if (body.trim().startsWith('{')) {
      // Veio como JSON direto (Make enviou JSON)
      payload = JSON.parse(body);
      // Garantir id_formulario a partir do campo nome_formulario ou id_formulario
      if (!payload.id_formulario && payload.nome_formulario) {
        const m = payload.nome_formulario;
        if (/casa/i.test(m))           payload.id_formulario = 'F_CASA';
        else if (/medica/i.test(m))    payload.id_formulario = 'F_MEDICACAO';
        else if (/escola/i.test(m))    payload.id_formulario = 'F_ESCOLA';
        else if (/social/i.test(m))    payload.id_formulario = 'F_SOCIAL';
        else if (/autonomia/i.test(m)) payload.id_formulario = 'F_AUTONOMIA';
      }
    } else {
      // Veio como texto puro (payload e-mail Formspree)
      payload = parsePayload(body);
    }

    if (!payload.id_formulario) {
      return {
        statusCode: 400,
        headers,
        body: JSON.stringify({ erro: 'Formulário não identificado. Verifique o campo id_formulario ou nome_formulario.' })
      };
    }

    const resultado = processar(payload);
    if (!resultado) {
      return {
        statusCode: 400,
        headers,
        body: JSON.stringify({ erro: 'Pilar não reconhecido: ' + payload.id_formulario })
      };
    }

    // Montar resposta estruturada para o Make / Google Sheets
    const resposta = {
      // Identificação
      nome_crianca:    payload.nome_crianca   || '',
      responsavel:     payload.responsavel    || '',
      idade:           payload.idade          || '',
      periodo:         payload.periodo_observado || '',
      usa_medicacao:   payload.usa_medicacao  || '',
      data_envio:      new Date().toLocaleDateString('pt-BR'),

      // Pilar
      pilar:           resultado.pilar.nome,
      id_formulario:   payload.id_formulario,

      // Resultado
      pontuacao:       resultado.soma,
      pontuacao_total: resultado.soma + '/25',
      nivel:           resultado.nivel,
      nivel_label:     ['','Nível 1 — Manutenção ativa','Nível 2 — Suporte preventivo-focal','Nível 3 — Suporte prioritário','Nível 4 — Suporte intensivo'][resultado.nivel],

      // Padrão
      codigo_padrao:   resultado.combinacao.codigo,
      itens_altos:     resultado.altos.join(', ')   || 'nenhum',
      itens_moderados: resultado.moderados.join(', ') || 'nenhum',
      alertas:         resultado.alertas.join('; ')  || 'nenhum',

      // Leitura
      leitura_interna: resultado.combinacao.leitura,
      primeiro_movimento: resultado.combinacao.acao,
      blocos_indicados: resultado.blocos.join(' · ') || 'Manutenção ativa',
      estrategias:     resultado.estrategias.join('; ') || '',
      prazo_reavaliacao: resultado.prazo,

      // Flags
      alerta_ativo:    resultado.alertas.length > 0 ? 'SIM' : 'NÃO',
      escalonamento_clinico: resultado.escalonamentoClinico ? 'SIM — Revisar com Dr. Fabio' : 'NÃO',

      // Devolutiva completa
      devolutiva:      gerarDevolutiva(resultado)
    };

    return {
      statusCode: 200,
      headers,
      body: JSON.stringify(resposta)
    };

  } catch (err) {
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({ erro: 'Erro interno: ' + err.message })
    };
  }
};
